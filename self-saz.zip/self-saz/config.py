API_ID = '28285817'
API_HASH = '5c96b16dea2daf25995ef30a02424bb9'
BOT_TOKEN = '8468064858:AAFFzXy_YCJ6wghuOJQivCNfhbqjCA7Kq74'
SESSIONS_DIR = 'sessions'
TEHRAN_TIMEZONE = 'Asia/Tehran'
MAX_CONCURRENT_UPDATES = 5
FORCE_JOIN_CHANNEL_USERNAME = "in_airdroup"
FORCE_JOIN_CHANNEL_ID = -1002847775828

PERSIAN_NUMERALS = '۰۱۲۳۴۵۶۷۸۹'
ENGLISH_NUMERALS = '0123456789'

ADMIN_USER_IDS = 8497435557


COIN_DB_CONFIG = {
    'host': 'localhost',       # your DB host
    'port': 3306,              # your DB port
    'user': 'nunltx_self',        # your DB user
    'password': 'Zxcvbnm1111',  # your DB password
    'db': 'nunltx_self',           # your DB name
    'minsize': 5,
    'maxsize': 100000000,
    'autocommit': True,
}